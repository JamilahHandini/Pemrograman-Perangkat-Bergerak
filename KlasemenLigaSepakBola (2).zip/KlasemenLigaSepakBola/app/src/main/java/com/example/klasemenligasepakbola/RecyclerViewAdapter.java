package com.example.klasemenligasepakbola;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter extends
        RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{


    private List<Liga> mLiga;

    public RecyclerViewAdapter(List<Liga> ligas) {
        mLiga = ligas;
    }


    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.recyclerview_item, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(contactView);
        return viewHolder;
    }

    // Involves populating data into the item through holder
    @Override
    public void onBindViewHolder(RecyclerViewAdapter.ViewHolder holder, int position) {
        // Get the data model based on position
        Liga liga = mLiga.get(position);

        // Set item views based on your views and data model
        TextView peringkat = holder.peringkat;
        peringkat.setText(liga.getPeringkat());

        TextView nama_klub = holder.nama_klub;
        nama_klub.setText(liga.getNama_klub());

        TextView poin = holder.poin;
        poin.setText(liga.getPoin());
        
    }

    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        return mLiga.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView peringkat;
        public TextView nama_klub;
        public TextView poin;

        public ViewHolder(View itemView) {
            super(itemView);

            peringkat = (TextView) itemView.findViewById(R.id.rcy_peringkat);
            nama_klub = (TextView) itemView.findViewById(R.id.rcy_namaklub);
            poin = (TextView) itemView.findViewById(R.id.rcy_poin);
        }
    }




}
