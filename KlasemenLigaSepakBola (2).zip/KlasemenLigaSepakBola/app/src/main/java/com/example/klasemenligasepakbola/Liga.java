package com.example.klasemenligasepakbola;

import java.util.ArrayList;

public class Liga {

        private String peringkat, poin;
        private String nama_klub;

        private String total_main, menang, seri, kalah, gol_masuk, gol_kemasukan, selisih_gol;


    public Liga(String peringkat, String nama_klub, String poin){
        this.peringkat = peringkat;
        this.nama_klub = nama_klub;
        this.poin = poin;
    }

    public static ArrayList<Liga> createLigaList(ArrayList<Liga> liga, String peringkat, String nama_klub, String poin) {
        liga.add(new Liga(peringkat, nama_klub, poin));
        return liga;
    }

    public String getPeringkat() {
        return peringkat;
    }

    public String getPoin() {
        return poin;
    }

    public String getNama_klub() {
        return nama_klub;
    }

    public String getTotal_main() {
        return total_main;
    }

    public String getMenang() {
        return menang;
    }

    public String getSeri() {
        return seri;
    }

    public String getKalah() {
        return kalah;
    }

    public String getGol_kemasukan() {
        return gol_kemasukan;
    }

    public String getGol_masuk() {
        return gol_masuk;
    }

    public String getSelisih_gol() {
        return selisih_gol;
    }


    public void setMenang(String menang) {
        this.menang = menang;
    }

    public void setSeri(String seri) {
        this.seri = seri;
    }

    public void setKalah(String kalah) {
        this.kalah = kalah;
    }

    public void setTotal_main(String total_main) {
        this.total_main = total_main;
    }

    public void setGol_masuk(String gol_masuk) {
        this.gol_masuk = gol_masuk;
    }

    public void setGol_kemasukan(String gol_kemasukan) {
        this.gol_kemasukan = gol_kemasukan;
    }

    public void setSelisih_gol(String selisih_gol) {
        this.selisih_gol = selisih_gol;
    }

}