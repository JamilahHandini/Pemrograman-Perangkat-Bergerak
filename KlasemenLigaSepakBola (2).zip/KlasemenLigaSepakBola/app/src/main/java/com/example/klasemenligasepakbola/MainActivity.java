package com.example.klasemenligasepakbola;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Liga> mliga;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rvContacts = (RecyclerView) findViewById(R.id.recyclerview);

        // Initialize contacts
        mliga= new ArrayList<Liga>();
        mliga.add(new Liga( "1", "Bali United", "69"));
        mliga.add(new Liga("2", "Persib", "66"));
        mliga.add(new Liga("3", "Persebaya", "59"));
        mliga.add(new Liga("4", "Bhayangkara", "59"));
        mliga.add(new Liga( "5", "Arema", "58"));
        // Create adapter passing in the sample user data
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(mliga);
        // Attach the adapter to the recyclerview to populate items
        rvContacts.setAdapter(adapter);
        // Set layout manager to position the items
        rvContacts.setLayoutManager(new LinearLayoutManager(this));
        // That's all!
    }
}